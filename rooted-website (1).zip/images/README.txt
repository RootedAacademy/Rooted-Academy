Put your photos here with these exact names: classroom.jpg, play.jpg, story.jpg, art.jpg, entrance.jpg, rest.jpg, uniform.jpg. They replace the grey placeholders automatically.
